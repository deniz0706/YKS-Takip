package com.deniz0706.ykstakip.ui.home

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.deniz0706.ykstakip.data.StudyRepository
import com.deniz0706.ykstakip.domain.model.Exam
import com.deniz0706.ykstakip.domain.model.ExamType
import com.deniz0706.ykstakip.ui.theme.YksMotion
import com.deniz0706.ykstakip.ui.theme.YksTokens
import com.deniz0706.ykstakip.ui.theme.clayInset
import com.deniz0706.ykstakip.ui.theme.clayRaised
import com.deniz0706.ykstakip.util.Fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val GainColor = Color(0xFF3DDC97)

/**
 * Kokpit: the clay-style home screen.
 *
 * Every number comes from real data: exam records (TYT/AYT cards and charts),
 * today's question count and daily goal (outer ring), today's saved study
 * minutes (inner ring) and the days left to the exam (top bar).
 * The public signature is unchanged so the navigation graph needs no edits.
 */
@Composable
fun PremiumHomeDashboard(
    exams: List<Exam>,
    onNewExam: (ExamType) -> Unit,
    onOpenStudy: () -> Unit,
    onOpenAiCoach: () -> Unit,
    onOpenLearning: (String, String) -> Unit,
    aiCoachAdvice: String = "",
    aiCoachDate: String = "",
    reviewAlertCount: Int = 0,
    learningDoneCount: Int = 0,
    learningTotalCount: Int = 0,
    hasFocusSession: Boolean = false,
    daysLeft: Long? = null,
    todayQuestions: Int = 0,
    dailyGoal: Int? = null,
    targetTyt: Float? = null,
    targetAyt: Float? = null,
    daysLeftAyt: Long? = null
) {
    val c = MaterialTheme.colorScheme
    val context = LocalContext.current

    // Today's saved study minutes; re-read whenever today's question count changes.
    val todayMinutes by produceState(0, todayQuestions) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                StudyRepository(context).get(java.time.LocalDate.now().toString())?.studyMinutes ?: 0
            }.getOrDefault(0)
        }
    }

    val tytExams = remember(exams) { exams.filter { it.type == ExamType.TYT }.sortedBy { it.date } }
    val aytExams = remember(exams) { exams.filter { it.type == ExamType.AYT }.sortedBy { it.date } }

    BoxWithConstraints(modifier = Modifier.fillMaxSize().background(c.background)) {
        val tabletLayout = maxWidth >= 840.dp
        LazyVerticalGrid(
            columns = GridCells.Fixed(if (tabletLayout) 2 else 1),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                horizontal = if (tabletLayout) 28.dp else YksTokens.Space.pageHorizontal,
                vertical = YksTokens.Space.pageVertical
            ),
            horizontalArrangement = Arrangement.spacedBy(20.dp),
            verticalArrangement = Arrangement.spacedBy(YksTokens.Space.section + 4.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                ClayCountdownPill(daysLeft = daysLeft)
            }
            item {
                ClayGaugeCard(
                    todayQuestions = todayQuestions,
                    dailyGoal = dailyGoal,
                    todayMinutes = todayMinutes,
                    hasFocusSession = hasFocusSession,
                    onOpenStudy = onOpenStudy
                )
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    ClayNetCard(
                        title = "TYT Netleri",
                        exams = tytExams,
                        goal = targetTyt,
                        accent = c.primary,
                        modifier = Modifier.weight(1f)
                    )
                    ClayNetCard(
                        title = "AYT Netleri",
                        exams = aytExams,
                        goal = targetAyt,
                        accent = c.tertiary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                ClayQuickActions(
                    onAddQuestion = onOpenStudy,
                    onAddExam = { onNewExam(ExamType.TYT) },
                    onAddMistake = { onOpenLearning("TYT", "") }
                )
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                ClayNextStepsCard(
                    reviewAlertCount = reviewAlertCount,
                    learningDoneCount = learningDoneCount,
                    learningTotalCount = learningTotalCount,
                    aiCoachAdvice = aiCoachAdvice,
                    aiCoachDate = aiCoachDate,
                    onOpenLearning = onOpenLearning,
                    onOpenAiCoach = onOpenAiCoach
                )
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun ClayCountdownPill(daysLeft: Long?) {
    val c = MaterialTheme.colorScheme
    val progress by animateFloatAsState(
        targetValue = ClayHomeMath.countdownFraction(daysLeft),
        animationSpec = tween(durationMillis = YksMotion.progressMs),
        label = "countdown-progress"
    )
    val title = if (daysLeft != null && daysLeft >= 0L) "YKS'ye $daysLeft Gün" else "YKS Takip"
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clayRaised(shape = RoundedCornerShape(YksTokens.Shape.pill), depth = 8.dp)
            .padding(horizontal = 24.dp, vertical = 14.dp)
            .semantics(mergeDescendants = true) { contentDescription = title },
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = c.onSurface,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        ClayProgressTrack(progress = progress, color = c.primary)
    }
}

@Composable
private fun ClayProgressTrack(progress: Float, color: Color, modifier: Modifier = Modifier) {
    Box(modifier = modifier.fillMaxWidth().height(10.dp).clayInset()) {
        if (progress > 0f) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(progress.coerceIn(0.04f, 1f))
                    .height(10.dp)
                    .clip(RoundedCornerShape(YksTokens.Shape.pill))
                    .background(Brush.horizontalGradient(listOf(color.copy(alpha = 0.7f), color)))
            )
        }
    }
}

@Composable
private fun ClayGaugeCard(
    todayQuestions: Int,
    dailyGoal: Int?,
    todayMinutes: Int,
    hasFocusSession: Boolean,
    onOpenStudy: () -> Unit
) {
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(36.dp)
    val questions by animateFloatAsState(
        targetValue = ClayHomeMath.fraction(todayQuestions, dailyGoal),
        animationSpec = tween(durationMillis = YksMotion.progressMs),
        label = "gauge-questions"
    )
    val study by animateFloatAsState(
        targetValue = ClayHomeMath.studyFraction(todayMinutes),
        animationSpec = tween(durationMillis = YksMotion.progressMs),
        label = "gauge-study"
    )
    val questionLabel = if (dailyGoal != null && dailyGoal > 0) {
        "$todayQuestions/$dailyGoal Soru"
    } else {
        "$todayQuestions Soru"
    }
    val timeLabel = ClayHomeMath.formatStudyTime(todayMinutes)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clayRaised(shape = shape, depth = 12.dp)
            .clip(shape)
            .clickable(onClick = onOpenStudy)
            .padding(20.dp)
            .semantics(mergeDescendants = true) {
                contentDescription = "Bugün $questionLabel çözüldü, $timeLabel çalışıldı."
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxWidth(0.86f).aspectRatio(1f),
            contentAlignment = Alignment.Center
        ) {
            ClayRing(
                outer = questions,
                inner = study,
                outerColor = c.primary,
                innerColor = c.secondary,
                modifier = Modifier.fillMaxSize()
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = questionLabel,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = c.primary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "⏱ $timeLabel",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = c.secondary
                )
            }
        }
        Text(
            text = if (hasFocusSession) "Odak seansına devam et →" else "Çalışmaya başla →",
            style = MaterialTheme.typography.labelLarge,
            color = c.onSurfaceVariant
        )
    }
}

@Composable
private fun ClayRing(
    outer: Float,
    inner: Float,
    outerColor: Color,
    innerColor: Color,
    modifier: Modifier = Modifier
) {
    val track = MaterialTheme.colorScheme.surfaceDim
    Canvas(modifier = modifier) {
        val dim = size.minDimension
        val outerStroke = dim * 0.115f
        val innerStroke = dim * 0.085f
        val gap = dim * 0.05f

        fun ring(inset: Float, strokeWidth: Float, progress: Float, color: Color) {
            val diameter = dim - inset * 2f
            val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
            val arcSize = Size(diameter, diameter)
            drawArc(
                color = track,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            if (progress > 0f) {
                // Soft glow, solid tube, then a thin highlight along the tube.
                drawArc(
                    color = color.copy(alpha = 0.18f),
                    startAngle = -90f,
                    sweepAngle = 360f * progress,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth * 1.5f, cap = StrokeCap.Round)
                )
                drawArc(
                    color = color,
                    startAngle = -90f,
                    sweepAngle = 360f * progress,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
                drawArc(
                    color = Color.White.copy(alpha = 0.22f),
                    startAngle = -90f,
                    sweepAngle = 360f * progress,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth * 0.3f, cap = StrokeCap.Round)
                )
            }
        }

        ring(outerStroke / 2f, outerStroke, outer, outerColor)
        ring(outerStroke + gap + innerStroke / 2f, innerStroke, inner, innerColor)
    }
}

@Composable
private fun ClayNetCard(
    title: String,
    exams: List<Exam>,
    goal: Float?,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val c = MaterialTheme.colorScheme
    val latest = exams.lastOrNull()?.totalNet
    val previous = exams.getOrNull(exams.lastIndex - 1)?.totalNet
    val change = if (latest != null && previous != null) latest - previous else null
    val recent = remember(exams) { exams.takeLast(8).map { it.totalNet.toFloat() } }
    val average = remember(exams) { exams.map { it.totalNet }.takeIf { it.isNotEmpty() }?.average() }
    val best = remember(exams) { exams.maxOfOrNull { it.totalNet } }
    val reveal by animateFloatAsState(
        targetValue = if (recent.size >= 2) 1f else 0f,
        animationSpec = tween(durationMillis = YksMotion.progressMs),
        label = "net-card-reveal"
    )

    Column(
        modifier = modifier
            .clayRaised(shape = RoundedCornerShape(YksTokens.Shape.panel), depth = 10.dp)
            .padding(16.dp)
            .semantics(mergeDescendants = true) {
                contentDescription = "$title: ${Fmt.net(latest)}" +
                    (change?.let { ", değişim ${Fmt.netWithSign(it)}" } ?: "")
            },
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(text = title, style = MaterialTheme.typography.labelLarge, color = c.onSurfaceVariant)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = Fmt.net(latest),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = c.onSurface
            )
            if (change != null) {
                Text(
                    text = if (change >= 0) "↗" else "↘",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (change >= 0) GainColor else c.error
                )
            }
        }
        if (recent.size >= 2) {
            ClaySparkline(
                values = recent,
                reveal = reveal,
                color = accent,
                modifier = Modifier.fillMaxWidth().height(72.dp)
            )
        } else {
            Text(
                text = "Grafik için en az 2 deneme gerekli.",
                style = MaterialTheme.typography.bodySmall,
                color = c.onSurfaceVariant,
                modifier = Modifier.height(72.dp)
            )
        }
        if (exams.isNotEmpty()) {
            Text(
                text = "Ort. ${Fmt.net(average)} · Rekor ${Fmt.net(best)}",
                style = MaterialTheme.typography.labelSmall,
                color = c.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        goal?.let {
            Text(text = "Hedef: $it", style = MaterialTheme.typography.labelSmall, color = accent)
        }
    }
}

@Composable
private fun ClaySparkline(
    values: List<Float>,
    reveal: Float,
    color: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        if (values.size < 2) return@Canvas
        val low = values.minOrNull() ?: 0f
        val high = values.maxOrNull() ?: 1f
        val spread = (high - low).coerceAtLeast(1f)
        val inset = 6.dp.toPx()
        val chartWidth = (size.width - inset * 2).coerceAtLeast(1f)
        val chartHeight = (size.height - inset * 2).coerceAtLeast(1f)
        val points = values.mapIndexed { index, value ->
            Offset(
                x = inset + chartWidth * index / values.lastIndex.toFloat(),
                y = inset + chartHeight * (1f - (value - low) / spread)
            )
        }
        val curve = Path().apply {
            moveTo(points.first().x, points.first().y)
            for (index in 0 until points.lastIndex) {
                val current = points[index]
                val next = points[index + 1]
                val controlX = (current.x + next.x) / 2f
                cubicTo(controlX, current.y, controlX, next.y, next.x, next.y)
            }
        }
        val area = Path().apply {
            addPath(curve)
            lineTo(points.last().x, size.height)
            lineTo(points.first().x, size.height)
            close()
        }
        clipRect(right = inset + chartWidth * reveal) {
            drawPath(
                path = area,
                brush = Brush.verticalGradient(
                    colors = listOf(color.copy(alpha = 0.35f), color.copy(alpha = 0.02f)),
                    startY = 0f,
                    endY = size.height
                )
            )
            drawPath(
                path = curve,
                color = color,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )
            drawCircle(color = color, radius = 4.dp.toPx(), center = points.last())
        }
    }
}

@Composable
private fun ClayQuickActions(
    onAddQuestion: () -> Unit,
    onAddExam: () -> Unit,
    onAddMistake: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ClayPill(text = "+ Soru Ekle", onClick = onAddQuestion, modifier = Modifier.weight(1f))
        ClayPill(text = "+ Deneme Gir", onClick = onAddExam, modifier = Modifier.weight(1f))
        ClayPill(text = "+ Hata Kaydet", onClick = onAddMistake, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun ClayPill(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(YksTokens.Shape.pill)
    Box(
        modifier = modifier
            .clayRaised(shape = shape, depth = 6.dp)
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = c.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun ClayNextStepsCard(
    reviewAlertCount: Int,
    learningDoneCount: Int,
    learningTotalCount: Int,
    aiCoachAdvice: String,
    aiCoachDate: String,
    onOpenLearning: (String, String) -> Unit,
    onOpenAiCoach: () -> Unit
) {
    val c = MaterialTheme.colorScheme
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clayRaised(shape = RoundedCornerShape(YksTokens.Shape.panel), depth = 10.dp)
            .padding(YksTokens.Space.cardContent),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Sıradaki Adımlar",
            style = MaterialTheme.typography.labelLarge,
            color = c.onSurfaceVariant
        )
        if (reviewAlertCount > 0) {
            ClayActionRow(
                glyph = "↻",
                title = "Tekrar önerileri ($reviewAlertCount)",
                subtitle = "$learningDoneCount/$learningTotalCount kazanım tamamlandı",
                accent = c.secondary,
                onClick = { onOpenLearning("TYT", "") }
            )
        }
        ClayActionRow(
            glyph = "✦",
            title = "AI Koç ile konuş",
            subtitle = if (aiCoachAdvice.isBlank()) "Denemelerinize göre kişisel öneri al." else aiCoachAdvice,
            accent = c.primary,
            onClick = onOpenAiCoach
        )
        if (aiCoachAdvice.isNotBlank() && aiCoachDate.isNotBlank()) {
            Text(
                text = "Son değerlendirme · $aiCoachDate",
                style = MaterialTheme.typography.bodySmall,
                color = c.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ClayActionRow(
    glyph: String,
    title: String,
    subtitle: String,
    accent: Color,
    onClick: () -> Unit
) {
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(YksTokens.Shape.card)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clayInset(shape)
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(text = glyph, style = MaterialTheme.typography.titleLarge, color = accent)
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = c.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = c.onSurfaceVariant,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
