package com.deniz0706.ykstakip.ui.home

/**
 * Pure helpers for the Kokpit (home) gauges. No Android or Compose types,
 * so they are covered by plain JVM unit tests.
 */
internal object ClayHomeMath {
    /** Inner ring is full at this many study minutes in a day (4 hours). */
    const val STUDY_MINUTES_REFERENCE = 240

    /** The countdown bar is empty 365 days before the exam and full on exam day. */
    const val EXAM_SPAN_DAYS = 365L

    fun fraction(done: Int, total: Int?): Float {
        if (total == null || total <= 0) return 0f
        return (done.coerceAtLeast(0).toFloat() / total.toFloat()).coerceIn(0f, 1f)
    }

    fun studyFraction(minutes: Int): Float =
        (minutes.coerceAtLeast(0).toFloat() / STUDY_MINUTES_REFERENCE).coerceIn(0f, 1f)

    fun countdownFraction(daysLeft: Long?): Float {
        if (daysLeft == null || daysLeft < 0L) return 0f
        return (1f - daysLeft.toFloat() / EXAM_SPAN_DAYS.toFloat()).coerceIn(0f, 1f)
    }

    /** 200 -> "3s 20dk", 45 -> "45dk". */
    fun formatStudyTime(minutes: Int): String {
        val safe = minutes.coerceAtLeast(0)
        val hours = safe / 60
        val rest = safe % 60
        return if (hours == 0) "${rest}dk" else "${hours}s ${rest}dk"
    }
}
