# Clay UI — uygulama adımları

Bunlar testten geçmedi. Önce dal aç (`4.0/clay-ui`), sonra push edip CI'ın sonucuna bak.

## 1) Yeni / komple değişen dosyalar (klasör yapısı aynı)

Bu klasördeki dosyaları repoya aynı yola kopyala:

- `app/src/main/java/com/deniz0706/ykstakip/ui/theme/YksClay.kt` (yeni)
- `app/src/main/java/com/deniz0706/ykstakip/ui/home/ClayHomeMath.kt` (yeni)
- `app/src/main/java/com/deniz0706/ykstakip/ui/navigation/ClayBottomBar.kt` (yeni)
- `app/src/test/java/com/deniz0706/ykstakip/ui/home/ClayHomeMathTest.kt` (yeni)
- `app/src/main/java/com/deniz0706/ykstakip/ui/components/YksCard.kt` (eskisinin yerine)
- `app/src/main/java/com/deniz0706/ykstakip/ui/home/PremiumHomeDashboard.kt` (eskisinin yerine)

## 2) Küçük düzenlemeler (5 dosya)

### A) `ui/theme/YksColorSystem.kt` — `val Dark = YksPalette(...)` bloğunu komple şununla değiştir

```kotlin
    /** Graphite Clay: koyu antrasit zemin, camgöbeği / mor / amber vurgular. */
    val Dark = YksPalette(
        name = "dark",
        background = Color(0xFF121317),
        surface = Color(0xFF1A1B20),
        surfaceContainer = Color(0xFF22242A),
        surfaceBright = Color(0xFF2A2C33),
        surfaceDim = Color(0xFF0D0E11),
        outline = Color(0xFF3A3D45),
        outlineVariant = Color(0xFF2C2F36),
        onSurface = Color(0xFFEDEFF3),
        onSurfaceVariant = Color(0xFFA3A9B5),
        primary = Color(0xFF4FD1F0),
        onPrimary = Color(0xFF06222B),
        primaryContainer = Color(0xFF14495A),
        onPrimaryContainer = Color(0xFFCDF3FF),
        secondary = Color(0xFFB197FC),
        onSecondary = Color(0xFF1E1240),
        secondaryContainer = Color(0xFF3E3266),
        onSecondaryContainer = Color(0xFFEADFFF),
        tertiary = Color(0xFFF4A65B),
        onTertiary = Color(0xFF3B1F00),
        tertiaryContainer = Color(0xFF5A3A17),
        onTertiaryContainer = Color(0xFFFFE2C4),
        error = Color(0xFFFF8A94),
        onError = Color(0xFF450A12),
        errorContainer = Color(0xFF66262E),
        onErrorContainer = Color(0xFFFFDADD),
        scrim = Color(0xB3000000)
    )
```

### B) `data/ThemeManager.kt` — `darkPalette` tanımını bununla değiştir

```kotlin
    private val darkPalette = palette(
        "#121317", "#1A1B20", "#22242A", "#EDEFF3",
        "#A3A9B5", "#4FD1F0", "#2C2F36", "#14495A"
    )
```

### C) `ui/theme/YksDesignSystem.kt` — `object Shape { ... }` bloğunu değiştir

```kotlin
    object Shape {
        val control = 16.dp     // buttons, chips, toggles
        val input = 20.dp       // text fields
        val card = 26.dp        // cards and panels
        val panel = 30.dp       // large containers
        val floating = 32.dp    // FAB, bottom sheets
        val pill = 100.dp       // fully rounded
        val circle = 50.dp      // avatars, circular icons
    }
```

### D) `ui/theme/YksDesignTokens.kt` — `object YksShape { ... }` bloğunu değiştir

```kotlin
object YksShape {
    val control = 16.dp
    val input = 20.dp
    val card = 26.dp
    val panel = 30.dp
    val floating = 32.dp
    val pill = 100.dp
}
```

### E) `ui/navigation/YksNavGraph.kt` — 4 değişiklik

**E1.** `YksPhoneShell` içindeki Surface:

```kotlin
            color = MaterialTheme.colorScheme.surface
```
→
```kotlin
            color = MaterialTheme.colorScheme.background
```

**E2.** `YksTabletShell` içindeki içerik Surface'i:

```kotlin
                color = c.surface
```
→
```kotlin
                color = c.background
```

**E3.** `YksTabletRail` içinde:

```kotlin
    NavigationRail(
        modifier = Modifier.fillMaxHeight()
    ) {
```
→
```kotlin
    NavigationRail(
        modifier = Modifier.fillMaxHeight(),
        containerColor = c.background
    ) {
```

**E4.** `YksBottomNavigation` fonksiyonunun tamamını bununla değiştir:

```kotlin
/** Bottom navigation bar for compact (phone) layouts. */
@Composable
fun YksBottomNavigation(
    currentDestination: YksNavDestination,
    navController: NavHostController,
    onDestinationSelected: (YksNavDestination) -> Unit
) {
    ClayBottomBar(
        currentDestination = currentDestination,
        onDestinationSelected = onDestinationSelected,
        onQuickAdd = { navController.navigate("exams/new") { launchSingleTop = true } }
    )
}
```

## 3) Neler değişti

- Tüm uygulama: Graphite palet artık Clay renkleri (cyan / mor / amber), köşeler daha yuvarlak, `YksCard` kabartmalı. `YksCard` kullanan her ekran otomatik değişir.
- Ana ekran (Kokpit): geri sayım çubuğu, ikili halka (soru / çalışma süresi), TYT ve AYT net kartları, hızlı butonlar, AI Koç kartı. Hepsi gerçek veriden.
- Alt bar: yüzen clay bar, ortada "+" (yeni deneme).
- Sıralama motoru, OBP, net hesabı, veri katmanı ve yedekleme koduna dokunulmadı.

## 4) Bilinen sınırlar

- Derlenmedi, çalıştırılmadı. Hata verirse CI logundaki satırı bana at.
- İç halkanın "tam" değeri günlük 4 saat varsayımı (`ClayHomeMath.STUDY_MINUTES_REFERENCE`). Çalışma süresi hedefi ayarlarda yok.
- Üstteki geri sayım çubuğu sınavdan 365 gün öncesini baz alır.
- Diğer ekranlar (İstatistik, Çalışma, Denemeler, Ayarlar) palet, köşe ve `YksCard` üzerinden yeni görünüme geçer. Kendi özel kartlarını kullanan yerler ayrıca elden geçirilmeli.
- Alt bardaki ikonlar hâlâ emoji. Vektör ikona geçiş sonraki adım.
