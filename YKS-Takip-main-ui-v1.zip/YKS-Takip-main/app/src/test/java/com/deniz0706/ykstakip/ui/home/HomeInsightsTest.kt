package com.deniz0706.ykstakip.ui.home

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class HomeInsightsTest {
    @Test fun subtitleWithoutGoalAndWithoutQuestions() =
        assertEquals("Hazırlığını verilerle takip et.", HomeInsights.subtitle(0, null))

    @Test fun subtitleWithoutGoalShowsSolvedCount() =
        assertEquals("Bugün 30 soru çözdün.", HomeInsights.subtitle(30, null))

    @Test fun subtitleWithGoalShowsProgress() =
        assertEquals("Bugün 30 / 100 soru.", HomeInsights.subtitle(30, 100))

    @Test fun subtitleWhenGoalReached() =
        assertEquals("Günlük hedefini tamamladın.", HomeInsights.subtitle(100, 100))

    @Test fun zeroGoalIsTreatedAsNoGoal() =
        assertEquals("Bugün 5 soru çözdün.", HomeInsights.subtitle(5, 0))

    @Test fun goalPercentRules() {
        assertNull(HomeInsights.goalPercent(null, 100f))
        assertNull(HomeInsights.goalPercent(50.0, null))
        assertNull(HomeInsights.goalPercent(50.0, 0f))
        assertEquals(50, HomeInsights.goalPercent(50.0, 100f))
        assertEquals(120, HomeInsights.goalPercent(120.0, 100f))
    }

    @Test fun trendWithoutExams() =
        assertEquals("İlk denemeni eklediğinde gelişim analizin burada görünecek.",
            HomeInsights.trendSentence(null, null, 0))

    @Test fun trendWithoutOlderPeriod() =
        assertEquals("İlk 3 denemen kaydedildi. Birkaç deneme daha ekleyince dönemleri karşılaştırabileceksin.",
            HomeInsights.trendSentence(80.0, null, 3))

    @Test fun trendRising() =
        assertEquals("Son 5 denemede yükseliş var. Önceki 5 denemeye göre ortalaman arttı.",
            HomeInsights.trendSentence(81.0, 80.0, 5))

    @Test fun trendFalling() =
        assertEquals("Son 5 denemede ortalama geriledi. Zayıf branşlarını inceleyebilirsin.",
            HomeInsights.trendSentence(79.0, 80.0, 5))

    @Test fun trendBalancedIncludingBoundary() {
        assertEquals("Son 5 denemede performansın dengeli seyrediyor.", HomeInsights.trendSentence(80.2, 80.0, 5))
        assertEquals("Son 5 denemede performansın dengeli seyrediyor.", HomeInsights.trendSentence(80.5, 80.0, 5))
    }
}
